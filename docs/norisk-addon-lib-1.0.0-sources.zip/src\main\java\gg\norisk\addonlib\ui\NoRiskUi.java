package gg.norisk.addonlib.ui;

import gg.norisk.owolib.owo.ui.component.ButtonComponent;
import gg.norisk.owolib.owo.ui.component.LabelComponent;
import gg.norisk.owolib.owo.ui.component.SliderComponent;
import gg.norisk.owolib.owo.ui.component.UIComponents;
import gg.norisk.owolib.owo.ui.container.FlowLayout;
import gg.norisk.owolib.owo.ui.core.Sizing;
import net.minecraft.network.chat.Component;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

public final class NoRiskUi {
    private NoRiskUi() {
    }

    public static LabelComponent section(FlowLayout panel, String title) {
        Objects.requireNonNull(panel, "panel");
        LabelComponent label = UIComponents.label(Component.literal(title));
        label.shadow(true);
        panel.child(label);
        return label;
    }

    public static LabelComponent label(FlowLayout panel, Component text) {
        Objects.requireNonNull(panel, "panel");
        LabelComponent label = UIComponents.label(Objects.requireNonNull(text, "text"));
        panel.child(label);
        return label;
    }

    public static ButtonComponent button(
            FlowLayout panel,
            Component text,
            Consumer<ButtonComponent> onClick
    ) {
        Objects.requireNonNull(panel, "panel");
        Objects.requireNonNull(onClick, "onClick");
        ButtonComponent button = UIComponents.button(
                Objects.requireNonNull(text, "text"),
                onClick
        );
        button.horizontalSizing(Sizing.fill(100));
        button.verticalSizing(Sizing.fixed(20));
        panel.child(button);
        return button;
    }

    public static ButtonComponent actionButton(FlowLayout panel, String text, Runnable action) {
        Objects.requireNonNull(action, "action");
        return button(panel, Component.literal(text), ignored -> action.run());
    }

    public static ButtonComponent toggle(
            FlowLayout panel,
            String label,
            Supplier<Boolean> getter,
            Consumer<Boolean> setter
    ) {
        Objects.requireNonNull(getter, "getter");
        Objects.requireNonNull(setter, "setter");
        ButtonComponent[] reference = new ButtonComponent[1];
        Runnable refresh = () -> reference[0].setMessage(toggleText(label, getter.get()));

        ButtonComponent button = button(panel, toggleText(label, getter.get()), ignored -> {
            setter.accept(!Boolean.TRUE.equals(getter.get()));
            refresh.run();
        });
        reference[0] = button;
        return button;
    }

    public static SliderComponent slider(
            FlowLayout panel,
            String label,
            double min,
            double max,
            double step,
            DoubleSupplier getter,
            DoubleConsumer setter
    ) {
        Objects.requireNonNull(panel, "panel");
        Objects.requireNonNull(getter, "getter");
        Objects.requireNonNull(setter, "setter");
        validateRange(min, max, step);

        SliderComponent slider = UIComponents.slider(Sizing.fill(100))
                .value((clamp(snap(getter.getAsDouble(), min, max, step), min, max) - min) / (max - min))
                .message(ignored -> label + ": " + format(getter.getAsDouble()));
        slider.onChanged().subscribe(progress -> {
            double value = min + clamp(progress, 0.0, 1.0) * (max - min);
            setter.accept(clamp(snap(value, min, max, step), min, max));
        });
        panel.child(slider);
        return slider;
    }

    private static Component toggleText(String label, Boolean active) {
        boolean enabled = Boolean.TRUE.equals(active);
        return Component.literal((enabled ? "[ON] " : "[OFF] ") + label);
    }

    private static double snap(double value, double min, double max, double step) {
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException("Slider value must be finite");
        }
        double snapped = min + Math.round((value - min) / step) * step;
        return clamp(snapped, min, max);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String format(double value) {
        return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
    }

    private static void validateRange(double min, double max, double step) {
        if (!Double.isFinite(min) || !Double.isFinite(max) || !Double.isFinite(step)
                || min >= max || step <= 0) {
            throw new IllegalArgumentException("Expected finite bounds with min < max and step > 0");
        }
    }
}
