package gg.norisk.addonlib.hud;

import gg.norisk.addonlib.value.NoRiskValues;
import gg.norisk.owolib.owo.ui.core.UIComponent;
import gg.norisk.ui.api.hud.AbstractHud;
import gg.norisk.ui.api.value.Value;

import java.util.Objects;
import java.util.function.Supplier;

public abstract class AddonHud extends AbstractHud {
    private final Supplier<? extends UIComponent> componentFactory;

    protected AddonHud(
            String name,
            boolean toggleable,
            boolean draggable,
            boolean enabled,
            Supplier<? extends UIComponent> componentFactory
    ) {
        super(name, toggleable, draggable, enabled);
        this.componentFactory = Objects.requireNonNull(componentFactory, "componentFactory");
    }

    @Override
    public final UIComponent hudComponent() {
        return Objects.requireNonNull(componentFactory.get(), "HUD component factory returned null");
    }

    protected final <T extends Value<?>> T registerValue(String key, T value) {
        return NoRiskValues.register(this, key, value);
    }
}
