Put the NoRisk Client, NRC abstraction, owo-lib, and Kotlin stdlib jars here
for local builds.

These jars are compile-time dependencies only and are intentionally not included
in this repository or in the library artifact. You can point Gradle at another
directory with `-PnrcLibsDir="D:\path\to\addon\libs"`.
