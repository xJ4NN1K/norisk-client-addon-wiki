# NoRisk Addon Lib

Kleine Java-Library, die wiederkehrenden Code für NoRisk-Client-Add-ons kapselt:

- NoRisk-Module und HUDs registrieren
- NRC-Values einem Modul/HUD zuordnen
- Boolean-, Integer- und Float-Values erstellen
- Buttons, Toggles, Slider und Überschriften in `FlowLayout`s aufbauen

Die Library ist **kein eigenes Fabric-Mod** und hat keine `fabric.mod.json`.
NoRisk Client und owo-lib sind Compile-Abhängigkeiten; der Spieler muss keine
separate Library-Mod installieren. Die API greift auf interne NoRisk-Klassen zu
und muss bei Änderungen am Client geprüft werden.

## Voraussetzungen

- Java 25
- Minecraft 26.3 / Fabric Loader 0.20.1
- Passende `norisk-client.jar`, `nrc-owolib.jar`, `nrc-abstraction.jar` und
  `kotlin-stdlib.jar`

Lege die vier JARs in `libs/`, oder übergib einen passenden Add-on-`libs`-Ordner
beim Build:

```powershell
.\gradlew.bat build -PnrcLibsDir="D:\NoRiskClient-Addons-Builder\Addons\NRC-BetterHud-Editor-Addon\libs"
```

Das Library-JAR liegt danach in `build\libs\`.

## In einem Add-on verwenden

Das Add-on kompiliert gegen die Library und bündelt ihre Klassen in seinem
eigenen Mod-JAR. So ist keine zusätzliche Library-Mod beim Spieler notwendig.
Zum Bündeln eignet sich Gradle Shadow; die Library-Klassen sollten in ein
add-on-eigenes internes Package verschoben werden, um Konflikte zwischen Mods
zu vermeiden. Beispiel für ein Loom-Projekt:

```groovy
plugins {
    id 'com.gradleup.shadow' version '9.2.2'
}

configurations {
    addonLib
    implementation.extendsFrom(addonLib)
}

dependencies {
    addonLib files('libs/norisk-addon-lib-1.0.0.jar')
}

shadowJar {
    configurations = [project.configurations.addonLib]
    relocate 'gg.norisk.addonlib', 'gg.norisk.addons.meinaddon.internal.addonlib'
}

tasks.named('remapJar') {
    dependsOn tasks.named('shadowJar')
    inputFile.set(tasks.named('shadowJar').flatMap { it.archiveFile })
}
```

Die `norisk-client.jar`, owo-lib und Minecraft/Fabric bleiben Compile-Abhängigkeiten
und werden nicht in das Add-on eingebettet.

## Schnellstart

```java
import gg.norisk.addonlib.NoRiskAddonLib;
import gg.norisk.addonlib.hud.AddonHud;
import gg.norisk.addonlib.module.AddonModule;
import gg.norisk.addonlib.ui.NoRiskUi;
import gg.norisk.owolib.owo.ui.component.UIComponents;
import gg.norisk.owolib.owo.ui.container.FlowLayout;
import gg.norisk.ui.api.module.ModuleCategory;
import gg.norisk.ui.api.value.BooleanValue;
import gg.norisk.ui.api.value.NumericValue;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
```

```java
public final class ExampleModule extends AddonModule {
    private final BooleanValue enabled;
    private final NumericValue strength;

    public ExampleModule() {
        super("Beispiel", ModuleCategory.QUALITY_OF_LIFE, true, false, true);

        enabled = booleanValue("enabled", true, "Aktiv", "Schaltet das Feature");
        strength = decimalValue("strength", 1.0f, 0.1f, 5.0f, 0.1f,
                "Stärke", "Legt die Stärke fest");
    }

    @Override
    public Function1<FlowLayout, Unit> buildCustomUi() {
        return customUi(panel -> {
            NoRiskUi.section(panel, "Mein Add-on");
            NoRiskUi.actionButton(panel, "Aktion", this::runAction);
            NoRiskUi.toggle(panel, "Aktiv", enabled::get, enabled::set);
            NoRiskUi.slider(panel, "Stärke", 0.1, 5.0, 0.1,
                    () -> strength.get().doubleValue(),
                    value -> strength.set((float) value));
        });
    }

    private void runAction() {
        // Add-on-Aktion
    }
}
```

Registrierung im Client-Entrypoint:

```java
NoRiskAddonLib.registerModule(new ExampleModule());
NoRiskAddonLib.registerHud(new ExampleHud());
```

`AddonHud` nimmt einen Supplier entgegen, der bei Bedarf die HUD-Komponente
erstellt:

```java
public final class ExampleHud extends AddonHud {
    public ExampleHud() {
        super("Beispiel HUD", true, true, true,
                () -> UIComponents.label("Hallo aus dem HUD"));
    }
}
```

## Bestehende NoRisk-Elemente erweitern

`NoRiskUi` baut Komponenten für NoRisk-`FlowLayout`s. Nutze das in den
Modul-Erweiterungspunkten wie `buildCustomUi()`, `buildNavbarActions(...)` oder
`buildCategoryUi(...)`, oder in einem eigenen HUD. `FlowLayout`-Komponenten
lassen sich auch in vorhandene Layouts einsetzen, wenn ein Hook/Mixin dir das
Layout bereitstellt.

Der Client stellt keine allgemeine, stabile API bereit, um beliebige bereits
existierende interne Screens automatisch zu verändern. Dafür braucht ein
konkreter Screen weiterhin einen versionsgebundenen Mixin/Hook; diese Library
ersetzt diesen Integrationsschritt nicht.
