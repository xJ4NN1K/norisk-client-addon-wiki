package gg.norisk.addonlib.value;

import gg.norisk.ui.api.value.Value;
import gg.norisk.ui.api.value.ValueHolder;

import java.lang.reflect.Field;
import java.util.Objects;

public final class NoRiskValues {
    private static final Field OWNER_FIELD = findOwnerField();

    private NoRiskValues() {
    }

    public static <T extends Value<?>> T register(ValueHolder owner, String key, T value) {
        Objects.requireNonNull(owner, "owner");
        Objects.requireNonNull(value, "value");
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("Value key must not be blank");
        }
        if (owner.getValues().stream().anyMatch(existing -> key.equals(existing.getName()))) {
            throw new IllegalArgumentException("Duplicate value key: " + key);
        }

        value.setName(key);
        try {
            OWNER_FIELD.set(value, owner);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Could not attach NoRisk value '" + key + "' to its owner", e);
        }
        owner.getValues().add(value);
        return value;
    }

    private static Field findOwnerField() {
        try {
            Field field = Value.class.getDeclaredField("module");
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException | RuntimeException e) {
            throw new ExceptionInInitializerError(e);
        }
    }
}
