package gg.norisk.addonlib.module;

import gg.norisk.addonlib.value.NoRiskValues;
import gg.norisk.ui.api.module.Module;
import gg.norisk.ui.api.module.ModuleCategory;
import gg.norisk.ui.api.value.BooleanValue;
import gg.norisk.ui.api.value.ButtonValue;
import gg.norisk.ui.api.value.NumericValue;
import gg.norisk.ui.api.value.Value;
import gg.norisk.owolib.owo.ui.component.ButtonComponent;
import gg.norisk.owolib.owo.ui.container.FlowLayout;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import net.minecraft.network.chat.Component;

import java.util.Objects;
import java.util.function.Consumer;

public abstract class AddonModule extends Module {
    protected AddonModule(
            String name,
            ModuleCategory category,
            boolean toggleable,
            boolean draggable,
            boolean enabled
    ) {
        super(name, category, toggleable, draggable, enabled);
    }

    protected final <T extends Value<?>> T registerValue(String key, T value) {
        return NoRiskValues.register(this, key, value);
    }

    protected final Function1<FlowLayout, Unit> customUi(Consumer<FlowLayout> builder) {
        Objects.requireNonNull(builder, "builder");
        return panel -> {
            builder.accept(panel);
            return Unit.INSTANCE;
        };
    }

    protected final BooleanValue booleanValue(
            String key,
            boolean initial,
            String label,
            String description
    ) {
        return booleanValue(key, initial, label, description, ignored -> {
        });
    }

    protected final BooleanValue booleanValue(
            String key,
            boolean initial,
            String label,
            String description,
            Consumer<Boolean> onChanged
    ) {
        BooleanValue value = new BooleanValue(
                initial,
                label,
                Component.literal(description),
                callback(onChanged)
        );
        return registerValue(key, value);
    }

    protected final NumericValue integerValue(
            String key,
            int initial,
            int min,
            int max,
            int step,
            String label,
            String description
    ) {
        return integerValue(key, initial, min, max, step, label, description, ignored -> {
        });
    }

    protected final NumericValue integerValue(
            String key,
            int initial,
            int min,
            int max,
            int step,
            String label,
            String description,
            Consumer<Number> onChanged
    ) {
        validateRange(min, max, step);
        if (initial < min || initial > max) {
            throw new IllegalArgumentException("Initial value must be within the configured range");
        }
        NumericValue value = new NumericValue(
                initial,
                new IntRange(min, max),
                step,
                label,
                Component.literal(description),
                callback(onChanged)
        );
        return registerValue(key, value);
    }

    protected final NumericValue decimalValue(
            String key,
            float initial,
            float min,
            float max,
            float step,
            String label,
            String description
    ) {
        return decimalValue(key, initial, min, max, step, label, description, ignored -> {
        });
    }

    protected final NumericValue decimalValue(
            String key,
            float initial,
            float min,
            float max,
            float step,
            String label,
            String description,
            Consumer<Number> onChanged
    ) {
        validateRange(min, max, step);
        if (!Float.isFinite(initial) || initial < min || initial > max) {
            throw new IllegalArgumentException("Initial value must be finite and within the configured range");
        }
        NumericValue value = new NumericValue(
                initial,
                RangesKt.rangeTo(min, max),
                step,
                label,
                Component.literal(description),
                callback(onChanged)
        );
        return registerValue(key, value);
    }

    protected final ButtonValue buttonValue(
            String key,
            String label,
            String description,
            Consumer<ButtonComponent> onClick
    ) {
        Objects.requireNonNull(onClick, "onClick");
        ButtonValue value = new ButtonValue(
                label,
                Component.literal(description),
                button -> {
                    onClick.accept(button);
                    return Unit.INSTANCE;
                }
        );
        return registerValue(key, value);
    }

    private static <T> Function1<T, Unit> callback(Consumer<? super T> onChanged) {
        Objects.requireNonNull(onChanged, "onChanged");
        return value -> {
            onChanged.accept(value);
            return Unit.INSTANCE;
        };
    }

    private static void validateRange(double min, double max, double step) {
        if (!Double.isFinite(min) || !Double.isFinite(max) || !Double.isFinite(step)
                || min > max || step <= 0) {
            throw new IllegalArgumentException("Expected finite bounds with min <= max and step > 0");
        }
    }
}
