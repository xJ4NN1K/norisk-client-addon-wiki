package gg.norisk.addonlib;

import gg.norisk.ui.api.hud.AbstractHud;
import gg.norisk.ui.api.module.Module;
import gg.norisk.ui.modules.api.ModuleProvider;
import gg.norisk.ui.v2.hud.components.HudComponentRegistry;

import java.util.Objects;

public final class NoRiskAddonLib {
    private NoRiskAddonLib() {
    }

    public static <T extends Module> T registerModule(T module) {
        Objects.requireNonNull(module, "module");
        ModuleProvider.Companion.register(module);
        return module;
    }

    public static <T extends AbstractHud> T registerHud(T hud) {
        Objects.requireNonNull(hud, "hud");
        HudComponentRegistry.INSTANCE.register(hud);
        return hud;
    }
}
